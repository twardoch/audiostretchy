// This is a dummy C file.
// Its purpose is to make setuptools generate a platform-specific wheel
// because this package includes pre-compiled binaries via package_data.
void dummy_function() {
}
